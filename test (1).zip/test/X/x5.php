<!DOCTYPE html>
<html>
<head>
    <title>Afficher un nom</title>
<link rel="shortcut icon" href="../Resources/hmbct.png" />
</head>
<body>
    
	 <div style="background-color:#c9c9c9;padding:15px;">
      <button type="button" name="homeButton" onclick="location.href='../homepage.html';">Home Page</button>
      <button type="button" name="mainButton" onclick="location.href='x.html';">Main Page</button>
    </div>
<div align="center">
<form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
   <p>votre nom<input type="text" name="username"></p>
   <input type="submit" name="submit" value="Submit">
</form>
    </div>

<?php 
if (isset($_GET["username"])) {
    $user = str_replace("<", "", $_GET["username"]);
    echo "Ton nom est "."$user";
}
 ?>

</body>
</html>
